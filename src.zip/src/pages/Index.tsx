import MarketingSite from "@/components/aostot/MarketingSite";

export default function Index() {
  return <MarketingSite />;
}
